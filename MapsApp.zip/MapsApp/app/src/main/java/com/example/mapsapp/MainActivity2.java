package com.example.mapsapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mapsapp.R;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity implements LocationListener{

    LocationManager locationManager;
    LocationListener locationListener;
    EditText editText, editText2;
    Button button3,button4,button5;
    List<Address> addresses;
    double lat,log;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editText = findViewById(R.id.editView);
        editText2 = findViewById(R.id.editView2);
        button3 = findViewById(R.id.button3);
        button5 = findViewById(R.id.button5);

        Places.initialize(getApplicationContext(),  "AIzaSyAFWGqabR24AySlq88MI6HnZs42x7IdttM");

        editText2.setFocusable(false);
        editText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG,Place.Field.NAME);

                Intent intent1 = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY,fieldList).build(MainActivity2.this);
                startActivityForResult(intent1,100);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name!=null && lat!=0 &&log!=0)
                {
                    DatabaseClass db = new DatabaseClass(MainActivity2.this);
                    db.addLocation(name,lat,log);
                    finish();
                }

                else
                {
                    Toast.makeText(MainActivity2.this, "Both Fields are Empty", Toast.LENGTH_SHORT).show();
                }

            }
        });


        if(ContextCompat.checkSelfPermission(MainActivity2.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity2.this,new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            },100);
        }

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });


    }

    @SuppressLint("MissingPermission")
    private void getLocation()
    {
        try
        {
            locationManager  = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5,MainActivity2.this);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        Toast.makeText(this, "" + location.getLatitude()+","+ location.getLongitude(), Toast.LENGTH_SHORT).show();
        lat =  location.getLatitude();
        log =  location.getLongitude();

        try
        {
            Geocoder geocoder = new Geocoder(MainActivity2.this, Locale.getDefault());
            addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);

            editText2.setText(address);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
    }


    public void map(View v) {
        name = editText.getText().toString();
        Intent intent = new Intent(MainActivity2.this,MapsActivity.class);
        intent.putExtra("latitude",lat);
        intent.putExtra("longitude",log);
        intent.putExtra("place",name);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK)
        {
            Place place = Autocomplete.getPlaceFromIntent(data);
            editText2.setText(place.getAddress());
            editText.setText(place.getName());

            lat = place.getLatLng().latitude;
            log = place.getLatLng().longitude;
            name = place.getName();
        }

        else if (resultCode == AutocompleteActivity.RESULT_ERROR)
        {
            Status status = Autocomplete.getStatusFromIntent(data);
            Toast.makeText(getApplicationContext(),status.getStatusMessage(),Toast.LENGTH_SHORT).show();
        }
    }



}